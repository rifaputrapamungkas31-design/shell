          <button class="btn btn-sm" style="background:#f59e0b;border-color:#f59e0b;color:#000;font-weight:600;white-space:nowrap;" onclick="doAutoRootCustom()">Run</button>
                </div>
            </div>

            <!-- Execution Log -->
            <div id="arLogPanel" style="display:none;margin-top:14px;">
                <div style="font-size:11px;font-weight:600;color:var(--text-secondary);margin-bottom:6px;">Execution Log</div>
                <pre id="arLog" style="background:#0a0a0a;border:1px solid var(--border);border-radius:6px;padding:12px;font-size:10px;color:#e0e0e0;max-height:250px;overflow-y:auto;white-space:pre-wrap;line-height:1.5;"></pre>
                <div id="arRootBanner" style="display:none;background:rgba(63,185,80,0.12);border:2px solid #3fb950;border-radius:8px;padding:14px;text-align:center;margin-top:10px;">
                    <div style="font-size:18px;font-weight:800;color:#3fb950;">ROOT ACCESS OBTAINED</div>
                    <div style=