ntent').style.display = 'none';
    document.getElementById('editFileContent').value = '';
    document.getElementById('editSaveBtn').disabled = true;
    document.getElementById('editFileModal').classList.remove('hidden');
    fileActionRequest({file_action: 'get_content', file_path: path}, function(r) {
        document.getElementById('editLoading').style.display = 'none';
        if (r.err) {
            document.getElementById('editFileContent').style.display = '';
            document.getElementById('editFileContent').value = 'Error: ' + r.err;
        } else {
            document.getElementById('editFileContent').style.display = '';
            document.getElementById('editFileContent').value = r.content;
            document.getElementById('editSaveBtn').disabled = false;
        }
    });
}
function hideEditModal() { document.getElementById('editFileModal').classList.add('hidden'); }
function saveEditFile() {
    var path = document.getElementById('editFilePath').value;
    va