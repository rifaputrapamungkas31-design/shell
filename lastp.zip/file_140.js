code></p>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 10px;">
                <div class="form-group" style="margin-bottom:0;">
                    <label class="form-label">Host / IP</label>
                    <input type="text" id="bcHost" class="form-input" placeholder="e.g. 192.168.1.100">
                </div>
                <div class="form-group" style="margin-bottom:0;">
                    <label class="form-label">Port</label>
                    <input type="number" id="bcPort" class="form-input" placeholder="e.g. 4444" min="1" max="65535">
                </div>
            </div>
            <div class="form-group" style="margin-bottom: 12px;">
                <label class="form-label">Method</label>
                <select id="bcType" class="form-input" onchange="updateBcPreview()">
                    <option value="php">PHP (fsockopen + proc_open)</option>
                    <option value="perl"