nput" placeholder="e.g. /var/www/html/public or /etc/passwd">
            </div>
            <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label">Link Name <span style="color: var(--text-muted); font-weight: 400;">(name of the symlink)</span></label>
                <input type="text" id="symlinkName" class="form-input" placeholder="e.g. link_to_public">
            </div>
            <div style="background: rgba(167,139,250,0.06); border: 1px solid rgba(167,139,250,0.15); border-radius: 6px; padding: 8px 10px; margin-top: 14px;">
                <p style="color: #a78bfa; font-size: 10px; font-family: monospace;" id="symlinkPreview">symlink: link_name -> /target/path</p>
            </div>
        </div>
        <div class="modal-footer" style="justify-content: center; gap: 12px;">
            <button class="btn btn-secondary" onclick="hideModal2('symlinkModal')">Cancel</button>
            <button class="btn" style="background: #a78bfa; border-c