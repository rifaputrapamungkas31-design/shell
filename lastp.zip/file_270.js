//media.tenor.com/uDnFP6VcaEYAAAAm/luffy-one-piece.webp'
    ];

    var chars = [];
    var COUNT = 5;

    function rand(min, max) { return Math.random() * (max - min) + min; }

    function spawnChar(idx) {
        var img = document.createElement('img');
        img.src = gifs[idx % gifs.length];
        img.style.cssText = 'position:fixed;z-index:99999;pointer-events:none;width:48px;height:48px;object-fit:contain;image-rendering:pixelated;opacity:0.85;transition:transform 0.3s ease;';
        document.body.appendChild(img);

        var ch = {
            el: img,
            x: rand(0, window.innerWidth - 48),
            y: rand(0, window.innerHeight - 48),
            vx: rand(0.3, 1.2) * (Math.random() > 0.5 ? 1 : -1),
            vy: rand(0.2, 0.8) * (Math.random() > 0.5 ? 1 : -1),
            targetX: rand(0, window.innerWidth - 48),
            targetY: rand(0, window.innerHeight - 48),
            timer: 0,
            changeDir: rand(120, 400)
        };
        img.style