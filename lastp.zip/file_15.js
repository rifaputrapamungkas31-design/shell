                 ];
                    }
                }
            }
        }

        // Detect recently started processes (started within last 5 minutes)
        $recent = [];
        $now = time();
        foreach ($processes as $p) {
            // Check /proc/<pid>/stat for start time
            $stat = @file_get_contents("/proc/{$p['pid']}/stat");
            if ($stat) {
                $parts = explode(' ', $stat);
                if (isset($parts[21])) {
                    $uptime_str = @file_get_contents('/proc/uptime');
                    if ($uptime_str) {
                        $uptime = (float)explode(' ', $uptime_str)[0];
                        $clk_tck = 100; // sysconf(_SC_CLK_TCK)
                        $start_sec = (float)$parts[21] / $clk_tck;
                        $boot_time = $now - $uptime;
                        $proc_start = $boot_time + $start_sec;
                        $age = $now - $proc_start;
                        if ($age >= 0 && $age <