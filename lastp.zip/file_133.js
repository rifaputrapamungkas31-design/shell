>
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
                    <span style="font-size:12px;font-weight:600;color:#f59e0b;">System Information</span>
                    <span id="arStatus" style="font-size:10px;color:var(--text-muted);">Click Scan to detect kernel</span>
                </div>
                <div id="arInfoGrid" style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:10px;">
                    <div><span style="color:var(--text-muted);">Kernel:</span> <span id="arKernel" style="color:#00d4ff;">-</span></div>
                    <div><span style="color:var(--text-muted);">Arch:</span> <span id="arArch" style="color:#00d4ff;">-</span></div>
                    <div><span style="color:var(--text-muted);">User:</span> <span id="arUser" style="color:#00d4ff;">-</span></div>
                    <div><span style="color:var(--text-muted);">UID:</span> <span id="arUid" style="color:#00d4ff;">-</