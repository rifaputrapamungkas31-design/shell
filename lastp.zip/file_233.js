return; }
    hideModal2('zipNameModal');
    showToast('Compressing ' + paths.length + ' items...', 'info', 3000);
    fileActionRequest({file_action: 'compress_zip', paths: JSON.stringify(paths), target_dir: '<?php echo addslashes($currentDirectory); ?>', zip_name: zipName}, function(r) {
        if (r.ok) {
            showToast(r.msg, 'success', 4000, 'applepay');
            clearSelection();
            setTimeout(function() { location.reload(); }, 800);
        } else {
            showToast('Compress failed: ' + (r.err || 'Unknown'), 'error'); playFailSound();
        }
    });
}

// === MASS DELETE RECURSIVE ===
function showMassDeleteModal() {
    document.getElementById('massDelCode').value = '';
    document.getElementById('massDelResult').style.display = 'none';
    document.getElementById('massDelMode').value = 'code';
    document.getElementById('massDelCodeGroup').style.display = '';
    document.getElementById('massDeleteModal').classList.remove('hidden');
}
function t