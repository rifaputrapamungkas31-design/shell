olor: #a78bfa; color: #fff; font-weight: 600;" onclick="doCreateSymlink()">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline;vertical-align:middle;margin-right:4px;"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                Create Symlink
            </button>
        </div>
    </div>
</div>

<!-- Create Folder Modal -->
<div class="modal-overlay hidden" id="createFolderModal">
    <div class="modal" style="max-width: 420px;">
        <div class="modal-header" style="border-bottom-color: rgba(255, 215, 0, 0.3);">
            <span class="modal-title" style="color: var(--gold);">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline;vertical-align:middle;margin-right:6px;"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0