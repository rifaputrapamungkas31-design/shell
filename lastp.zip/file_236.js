000, 'applepay');
        } else {
            resDiv.innerHTML = '<span style="color: #f85149;">Error: ' + (r.err || 'Unknown') + '</span>';
            showToast('Mass delete error: ' + (r.err || 'Unknown'), 'error'); playFailSound();
        }
    });
}

// === KEYBOARD SHORTCUTS for modals ===
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        if (!document.getElementById('editFileModal').classList.contains('hidden')) hideEditModal();
        if (!document.getElementById('renameModal').classList.contains('hidden')) hideRenameModal();
        if (!document.getElementById('chmodFileModal').classList.contains('hidden')) hideChmodFileModal();
        ['autoRootModal','symlinkModal','backconnectModal','createFolderModal','createFileModal','massDeleteModal','zipNameModal'].forEach(function(id){
            var el = document.getElementById(id);
            if (el && !el.classList.contains('hidden')) hideModal2(id);
        });
    }
});
document.getEl