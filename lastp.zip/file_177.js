o;padding:5px 8px;font-size:11px;" onchange="procFilterRender()">
                    <option value="all">All Processes</option>
                    <option value="mine">My Processes</option>
                    <option value="hidden">Hidden Only</option>
                    <option value="recent">Recent (5min)</option>
                </select>
                <select id="procSort" class="form-input" style="width:auto;padding:5px 8px;font-size:11px;" onchange="procFilterRender()">
                    <option value="cpu">Sort: CPU</option>
                    <option value="mem">Sort: MEM</option>
                    <option value="pid">Sort: PID</option>
                    <option value="start">Sort: Start</option>
                </select>
            </div>

            <!-- Alert badges -->
            <div id="procAlerts" style="display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap;"></div>

            <!-- Process table -->
            <div style="flex:1;overflow:auto;border:1p