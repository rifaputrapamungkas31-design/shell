r content = document.getElementById('editFileContent').value;
    var btn = document.getElementById('editSaveBtn');
    btn.disabled = true;
    btn.textContent = 'Saving...';
    var saveBtnReset = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline;vertical-align:middle;margin-right:4px;"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> Save File';
    fileActionRequest({file_action: 'save_content', file_path: path, file_content: content}, function(r) {
        if (r.ok) {
            showToast('File saved successfully: <b>' + path.split('/').pop() + '</b>', 'success', 4000, 'applepay');
            btn.textContent = 'Saved!';
            btn.style.background = '#3fb950';
            btn.style.borderColor = '#3fb950';
            setTimeout(function() { btn.disabled = false; btn.innerHTML = saveBtnReset; btn.