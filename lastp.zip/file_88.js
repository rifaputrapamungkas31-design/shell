77);
    color: white;
    border-color: #ec4899;
}
.btn-proc:hover {
    box-shadow: 0 0 15px rgba(236, 72, 153, 0.5);
}

.btn-cron {
    background: linear-gradient(135deg, #06b6d4, #0891b2);
    color: white;
    border-color: #06b6d4;
}
.btn-cron:hover {
    box-shadow: 0 0 15px rgba(6, 182, 212, 0.5);
}

.wp-user-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px;
    background: var(--bg-secondary);
    border: 1px solid var(--border);
    border-radius: 6px;
    margin-bottom: 4px;
}
.wp-user-row:hover { border-color: var(--accent); }
.wp-user-row.wp-hidden {
    background: rgba(59, 130, 246, 0.08);
    border-color: rgba(59, 130, 246, 0.3);
}
.wp-badge {
    display: inline-block;
    padding: 1px 6px;
    border-radius: 3px;
    font-size: 9px;
    font-weight: 700;
    text-transform: uppercase;
}
.wp-badge-hidden { background: #3b82f6; color: white; }
.wp-badge-admin { background: #f59e0b; color: #000; }
.wp-pw-box {
    display: inline-flex;