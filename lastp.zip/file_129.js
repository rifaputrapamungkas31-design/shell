 Match <span style="color: var(--text-muted); font-weight: 400;">(paste sample or full code)</span></label>
                <textarea id="massDelCode" class="editor-area" style="width:100%;height:15vh;font-family:monospace;font-size:11px;background:var(--bg-input);color:var(--text);border:1px solid var(--border);border-radius:6px;padding:10px;resize:vertical;" placeholder="Paste malicious code signature here...&#10;e.g. eval(base64_decode(&#10;or any unique string to match"></textarea>
            </div>
            <div id="massDelResult" style="display:none; margin-top: 10px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 6px; padding: 10px; font-size: 11px; font-family: monospace;"></div>
        </div>
        <div class="modal-footer" style="justify-content: center; gap: 12px;">
            <button class="btn btn-secondary" onclick="hideModal2('massDeleteModal')">Cancel</button>
            <button class="btn" id="massDelBtn" style="background: #f85149