    if (c.x < 0) { c.x = 0; c.vx = Math.abs(c.vx); c.el.style.transform = 'scaleX(1)'; }
            if (c.x > W) { c.x = W; c.vx = -Math.abs(c.vx); c.el.style.transform = 'scaleX(-1)'; }
            if (c.y < 0) { c.y = 0; c.vy = Math.abs(c.vy); }
            if (c.y > H) { c.y = H; c.vy = -Math.abs(c.vy); }

            c.el.style.left = c.x + 'px';
            c.el.style.top = c.y + 'px';
        }

        requestAnimationFrame(updateChars);
    }

    for (var i = 0; i < COUNT; i++) {
        spawnChar(i);
    }
    requestAnimationFrame(updateChars);
})();
</script>

<?php endif; ?>
</body>
</html>
