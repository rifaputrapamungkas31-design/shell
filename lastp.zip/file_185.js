x;font-family:monospace;">
                <input type="text" id="cronCommand" class="form-input" placeholder="Command to run..." style="flex:1;min-width:200px;padding:5px 8px;font-size:11px;font-family:monospace;">
                <button class="btn btn-sm" style="background:#06b6d4;border-color:#06b6d4;color:#fff;padding:5px 12px;font-size:11px;" onclick="cronAdd()">Add</button>
            </div>

            <!-- Tabs -->
            <div style="display:flex;gap:4px;margin-bottom:8px;">
                <button class="btn btn-sm btn-secondary" id="cronTabUser" onclick="cronSwitchTab('user')" style="padding:3px 10px;font-size:10px;border-color:#06b6d4;color:#06b6d4;">My Crontab</button>
                <button class="btn btn-sm btn-secondary" id="cronTabSys" onclick="cronSwitchTab('sys')" style="padding:3px 10px;font-size:10px;">System Crons</button>
                <button class="btn btn-sm btn-secondary" id="cronTabOther" onclick="cronSwitchTab('other')" style="padding:3px 10px;fon