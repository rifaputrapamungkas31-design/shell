" style="animation-duration:' + duration + 'ms;"></div>';
    container.appendChild(toast);
    toast.addEventListener('click', function(e) { if (e.target.tagName !== 'BUTTON') removeToast(toast); });
    setTimeout(function() { removeToast(toast); }, duration);
}

function removeToast(el) {
    if (!el || el.classList.contains('toast-removing')) return;
    el.classList.add('toast-removing');
    setTimeout(function() { if (el.parentNode) el.parentNode.removeChild(el); }, 350);
}

// Page-load toast: check URL for msg param + PHP messages + login sound
var _pageToastFired = false;
(function() {
    var url = new URL(window.location.href);
    var msg = url.searchParams.get('msg');
    if (msg === 'deleted') {
        _pageToastFired = true;
        setTimeout(function() { showToast('Item deleted successfully', 'success', 4000, 'applepay'); }, 300);
        url.searchParams.delete('msg');
        window.history.replaceState({}, '', url.pathname + url.search);
    }

    // PHP-rendered